<form action="https://www.example.com/payment/success/" method="POST">
<script
    src="https://checkout.razorpay.com/v1/checkout.js"
    data-key="rzp_test_kHjgi2qZqI89jj"
    data-amount="10000"
    data-currency="INR"
    data-order_id="order_CgmcjRh9ti2lP7"
    data-buttontext="Pay with Razorpay"
    data-name="Travel."
    data-description="A tour & travel website"
    data-image="images/logo.jpg"
    data-prefill.name=""
    data-prefill.email=""
    data-theme.color="#8e44ad"
></script>
<input type="hidden" custom="Hidden Element" name="hidden"/>
</form>